CKEDITOR.plugins.setLang('bgimage','en',{
	bgImageTitle : 'Background image',
	imageUrl     : 'Image URL',
	repeat	     : 'Repeat',
	attachment   : 'Attachment',
	blendMode    : 'Blend mode',
	position	 : 'Position',
	bgWidth    : 'Width (CSS unit eg: 20px)',
	bgHeight	 : 'Height (CSS unit eg: 20%)'
})
