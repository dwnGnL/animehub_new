<main class="pt-5 mx-lg-5">
    <div class="container-fluid mt-5">
        <h4 class="">Добавить канал</h4>
        <div class="card mb-4 wow fadeIn">
            <div class="card-body d-sm-flex ">
                <span id="suck"></span>
                <input type="search" name="search"  class="form-control mr-5" id="addChannel" placeholder="Введите название канала" style="width:90%;">
                <button id="saveChannel" class="btn btn-primary btn-sm mr-5 ml-5" name="btn">X</button>

            </div>
        </div>
    </div>
</main>
