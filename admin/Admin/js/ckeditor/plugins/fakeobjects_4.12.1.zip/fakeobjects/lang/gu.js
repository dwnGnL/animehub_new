/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'gu', {
	anchor: 'અનકર',
	flash: 'ફ્લેશ ',
	hiddenfield: 'હિડન ',
	iframe: 'IFrame',
	unknown: 'અનનોન ઓબ્જેક્ટ'
} );
