/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'hi', {
	anchor: 'ऐंकर इन्सर्ट/संपादन',
	flash: 'Flash Animation', // MISSING
	hiddenfield: 'गुप्त फ़ील्ड',
	iframe: 'IFrame', // MISSING
	unknown: 'Unknown Object' // MISSING
} );
