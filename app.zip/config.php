<?php
defined('_Sdef' ) or exit('Access denied');
define('PREF', 'lite_');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'animehub');


define('QUANTITY', 28);
define('QUANTITY_LINKS', 3);
?>