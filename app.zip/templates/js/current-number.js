let currentNumber = document.querySelectorAll('.current-number');

currentingNumber(currentNumber);

function currentingNumber(elem) {
  elem.forEach((item, index) => {
    item.innerHTML = index + 1;
  });
};
